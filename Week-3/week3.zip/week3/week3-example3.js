var colors = ["Red", "Green", "Blue"];
colors.push("Pink");  
colors.unshift("black");  
console.log(colors); 