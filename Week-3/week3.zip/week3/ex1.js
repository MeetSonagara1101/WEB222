function log(s){
    console.log(s);
}

log(["Hello", "Hi","Good afternoon"]);